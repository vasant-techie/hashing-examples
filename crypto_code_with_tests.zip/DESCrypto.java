import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class DESCrypto implements EncryptionAlgorithm {
    private static final String DES_ALGO = "DES";
    private SecretKey key;

    public DESCrypto(byte[] keyBytes) {
        this.key = new SecretKeySpec(keyBytes, DES_ALGO);
    }

    @Override
    public byte[] encrypt(String data) throws Exception {
        Cipher cipher = Cipher.getInstance(DES_ALGO);
        cipher.init(Cipher.ENCRYPT_MODE, key);
        return cipher.doFinal(data.getBytes());
    }

    @Override
    public String decrypt(byte[] encryptedData) throws Exception {
        Cipher cipher = Cipher.getInstance(DES_ALGO);
        cipher.init(Cipher.DECRYPT_MODE, key);
        byte[] decryptedData = cipher.doFinal(encryptedData);
        return new String(decryptedData);
    }
}

public class TripleDESCrypto implements EncryptionAlgorithm {
    private static final String TRIPLE_DES_ALGO = "DESede"; // 3DES
    private SecretKey key;

    public TripleDESCrypto(byte[] keyBytes) {
        this.key = new SecretKeySpec(keyBytes, TRIPLE_DES_ALGO);
    }

    @Override
    public byte[] encrypt(String data) throws Exception {
        Cipher cipher = Cipher.getInstance(TRIPLE_DES_ALGO);
        cipher.init(Cipher.ENCRYPT_MODE, key);
        return cipher.doFinal(data.getBytes());
    }

    @Override
    public String decrypt(byte[] encryptedData) throws Exception {
        Cipher cipher = Cipher.getInstance(TRIPLE_DES_ALGO);
        cipher.init(Cipher.DECRYPT_MODE, key);
        byte[] decryptedData = cipher.doFinal(encryptedData);
        return new String(decryptedData);
    }
}
