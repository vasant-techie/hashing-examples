import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class CryptoManagerTest {

    private CryptoManager aesCryptoManager;
    private CryptoManager desCryptoManager;
    private CryptoManager tripleDESCryptoManager;
    private CryptoManager rsaCryptoManager;
    private CryptoManager base64CryptoManager;

    private final byte[] aesKey = new byte[32]; // AES 256-bit key (32 bytes)
    private final byte[] aesIv = new byte[12]; // AES IV for GCM (12 bytes)

    private final byte[] desKey = new byte[8]; // DES key (8 bytes)
    private final byte[] tripleDESKey = new byte[24]; // 3DES key (24 bytes)

    private final byte[] publicKey = new byte[294];  // Example RSA public key bytes
    private final byte[] privateKey = new byte[1218]; // Example RSA private key bytes

    private final String data = "Sensitive Data";

    @BeforeEach
    public void setUp() throws Exception {
        aesCryptoManager = new CryptoManager("AES", aesKey, aesIv, null, null);
        desCryptoManager = new CryptoManager("DES", desKey, null, null, null);
        tripleDESCryptoManager = new CryptoManager("3DES", tripleDESKey, null, null, null);
        rsaCryptoManager = new CryptoManager("RSA", null, null, publicKey, privateKey);
        base64CryptoManager = new CryptoManager("BASE64", null, null, null, null);
    }

    @Test
    public void testAESCrypto() throws Exception {
        String encrypted = aesCryptoManager.encryptData(data);
        assertNotNull(encrypted);
        String decrypted = aesCryptoManager.decryptData(encrypted);
        assertEquals(data, decrypted);
    }

    @Test
    public void testDESCrypto() throws Exception {
        String encrypted = desCryptoManager.encryptData(data);
        assertNotNull(encrypted);
        String decrypted = desCryptoManager.decryptData(encrypted);
        assertEquals(data, decrypted);
    }

    @Test
    public void testTripleDESCrypto() throws Exception {
        String encrypted = tripleDESCryptoManager.encryptData(data);
        assertNotNull(encrypted);
        String decrypted = tripleDESCryptoManager.decryptData(encrypted);
        assertEquals(data, decrypted);
    }

    @Test
    public void testRSACrypto() throws Exception {
        String encrypted = rsaCryptoManager.encryptData(data);
        assertNotNull(encrypted);
        String decrypted = rsaCryptoManager.decryptData(encrypted);
        assertEquals(data, decrypted);
    }

    @Test
    public void testBase64Crypto() throws Exception {
        String encrypted = base64CryptoManager.encryptData(data);
        assertNotNull(encrypted);
        String decrypted = base64CryptoManager.decryptData(encrypted);
        assertEquals(data, decrypted);
    }
}
