import java.util.Base64;

public class CryptoManager {

    private EncryptionAlgorithm encryptionAlgorithm;

    public CryptoManager(String algorithm, byte[] key, byte[] iv, byte[] publicKey, byte[] privateKey) throws Exception {
        this.encryptionAlgorithm = CryptoFactory.getCrypto(algorithm, key, iv, publicKey, privateKey);
    }

    public String encryptData(String data) throws Exception {
        byte[] encryptedBytes = encryptionAlgorithm.encrypt(data);
        return Base64.getEncoder().encodeToString(encryptedBytes); // Return Base64 string for convenience
    }

    public String decryptData(String encryptedData) throws Exception {
        byte[] encryptedBytes = Base64.getDecoder().decode(encryptedData); // Decode Base64 to bytes
        return encryptionAlgorithm.decrypt(encryptedBytes);
    }

    public static void main(String[] args) throws Exception {
        // Symmetric AES Example
        byte[] aesKey = new byte[32]; // AES 256-bit key (32 bytes)
        byte[] aesIv = new byte[12];  // AES IV for GCM (12 bytes)

        CryptoManager aesCryptoManager = new CryptoManager("AES", aesKey, aesIv, null, null);
        String aesEncrypted = aesCryptoManager.encryptData("Sensitive AES Data");
        System.out.println("AES Encrypted: " + aesEncrypted);
        String aesDecrypted = aesCryptoManager.decryptData(aesEncrypted);
        System.out.println("AES Decrypted: " + aesDecrypted);

        // Asymmetric RSA Example
        byte[] publicKey = new byte[294];  // RSA public key bytes (example)
        byte[] privateKey = new byte[1218]; // RSA private key bytes (example)

        CryptoManager rsaCryptoManager = new CryptoManager("RSA", null, null, publicKey, privateKey);
        String rsaEncrypted = rsaCryptoManager.encryptData("Sensitive RSA Data");
        System.out.println("RSA Encrypted: " + rsaEncrypted);
        String rsaDecrypted = rsaCryptoManager.decryptData(rsaEncrypted);
        System.out.println("RSA Decrypted: " + rsaDecrypted);
    }
}
