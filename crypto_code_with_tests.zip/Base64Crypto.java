import java.util.Base64;

public class Base64Crypto implements EncryptionAlgorithm {

    @Override
    public byte[] encrypt(String data) throws Exception {
        return Base64.getEncoder().encode(data.getBytes());
    }

    @Override
    public String decrypt(byte[] encryptedData) throws Exception {
        return new String(Base64.getDecoder().decode(encryptedData));
    }
}
