public interface EncryptionAlgorithm {
    byte[] encrypt(String data) throws Exception;
    String decrypt(byte[] encryptedData) throws Exception;
}
