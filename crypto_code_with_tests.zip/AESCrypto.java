import org.bouncycastle.jce.provider.BouncyCastleProvider;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.Security;
import java.util.Base64;

public class AESCrypto implements EncryptionAlgorithm {

    private static final String AES_ALGO = "AES/GCM/NoPadding";
    private static final int GCM_TAG_LENGTH = 16; // 16 bytes authentication tag

    private SecretKey key;
    private byte[] iv;

    static {
        Security.addProvider(new BouncyCastleProvider());
    }

    // Constructor that accepts key and iv as inputs
    public AESCrypto(byte[] keyBytes, byte[] iv) {
        this.key = new SecretKeySpec(keyBytes, "AES"); // Convert byte array into SecretKey
        this.iv = iv; // Assign the passed IV
    }

    @Override
    public byte[] encrypt(String data) throws Exception {
        Cipher cipher = Cipher.getInstance(AES_ALGO, "BC");
        GCMParameterSpec gcmSpec = new GCMParameterSpec(GCM_TAG_LENGTH * 8, iv);
        cipher.init(Cipher.ENCRYPT_MODE, key, gcmSpec);
        return cipher.doFinal(data.getBytes());
    }

    @Override
    public String decrypt(byte[] encryptedData) throws Exception {
        Cipher cipher = Cipher.getInstance(AES_ALGO, "BC");
        GCMParameterSpec gcmSpec = new GCMParameterSpec(GCM_TAG_LENGTH * 8, iv);
        cipher.init(Cipher.DECRYPT_MODE, key, gcmSpec);
        byte[] decryptedData = cipher.doFinal(encryptedData);
        return new String(decryptedData);
    }
}
