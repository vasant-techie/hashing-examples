public class CryptoFactory {

    public static EncryptionAlgorithm getCrypto(String algorithm, byte[] key, byte[] iv, byte[] publicKey, byte[] privateKey) throws Exception {
        switch (algorithm.toUpperCase()) {
            case "AES":
                return new AESCrypto(key, iv); // AES requires both key and IV
            case "DES":
                return new DESCrypto(key); // DES uses only a key
            case "3DES":
                return new TripleDESCrypto(key); // Triple DES uses only a key
            case "RSA":
                return new RSACrypto(publicKey, privateKey); // RSA uses public and private key
            case "BASE64":
                return new Base64Crypto(); // No keys needed
            default:
                throw new IllegalArgumentException("Unknown encryption algorithm: " + algorithm);
        }
    }
}
